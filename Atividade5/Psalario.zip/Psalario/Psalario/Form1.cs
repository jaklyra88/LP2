﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {

        double salarioBruto;

        public Form1()
        {
            InitializeComponent();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void txtNomeFuncionario_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnVerDesc_Click(object sender, EventArgs e)
        {
            double descontoINSS, descontoIRPF, salFamilia, salLiquido;

            double filhos = 0;

            filhos = Convert.ToDouble(numdFilhos.Value);

            double.TryParse(mskbxAliINSS.Text, out salarioBruto);

            /* CÁLCULO DESCONTO INSS   */

            if (salarioBruto <= 800.47)
            {
                txtAliINSS.Text = "7,65%";
                descontoINSS = 0.0765 * salarioBruto;
                txtDescINSS.Text = descontoINSS.ToString("N2");
            }
            else if (salarioBruto <= 1050.00)
            {
                txtAliINSS.Text = "8,65%";
                descontoINSS = (8.65 / 100) * salarioBruto;
                txtDescINSS.Text = descontoINSS.ToString("N2");
            }
            else if (salarioBruto <= 1400.77)
            {
                txtAliINSS.Text = "9,00%";
                descontoINSS = (9.00 / 100) * salarioBruto;
                txtDescINSS.Text = descontoINSS.ToString("N2");
            }
            else if (salarioBruto <= 2801.56)
            {
                txtAliINSS.Text = "11,00%";
                descontoINSS = (11.00 / 100) * salarioBruto;
                txtDescINSS.Text = descontoINSS.ToString("N2");
            }
            else 
            {
                txtAliINSS.Text = "27,5%";
                descontoINSS = 308.17;
                txtDescINSS.Text = descontoINSS.ToString("N2");
            }




            /* CÁLCULO DESCONTO IRPF  */

            if (salarioBruto <= 1257.12)
            {
                txtAliIRPF.Text = "ISENTO";
                descontoIRPF = 0.00;
                txtDescIRPF.Text = descontoIRPF.ToString("N2");
            }
            else if (salarioBruto <= 2512.08)
            {
                txtAliIRPF.Text = "15.00%";
                descontoIRPF = (15.00 / 100) * salarioBruto;
                txtDescIRPF.Text = descontoIRPF.ToString("N2");
            }
            else
            {
                txtAliIRPF.Text = "27.5%";
                descontoIRPF = (27.5 / 100) * salarioBruto;
                txtDescIRPF.Text = descontoIRPF.ToString("N2");
            }


            /* CÁLCULO SALÁRIO FAMÍLIA  */



            if (salarioBruto <= 435.52)
            {
                salFamilia = filhos * 22.33;
                txtSalFamilia.Text = salFamilia.ToString("N2");
            }
            else if (salarioBruto <= 654.61)
            {
                salFamilia = filhos * 15.74;
                txtSalFamilia.Text = salFamilia.ToString("N2");
            }
            else
            {
                salFamilia = 0;
                txtSalFamilia.Text = salFamilia.ToString("N2");

            }



            salLiquido = salarioBruto - (descontoINSS + descontoIRPF) + salFamilia;

            txtSalLiquido.Text = salLiquido.ToString("N2");


           


        }

        private void btnLimparDados_Click(object sender, EventArgs e)
        {
            txtNomeFuncionario.Text = "";
            mskbxAliINSS.Text = " ";
            txtAliINSS.Text = "";
            txtAliIRPF.Text = "";
            txtDescINSS.Text = "";
            txtDescIRPF.Text = "";
            txtSalFamilia.Text = "";
            txtSalLiquido.Text = "";
            numdFilhos.Value = 0;

        }

        private void txtNomeFuncionario_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(Char.IsNumber(e.KeyChar)  ||
                Char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("Caracter Inválido");
                SendKeys.Send("{BACKSPACE}");
            }
        }
    }
}
