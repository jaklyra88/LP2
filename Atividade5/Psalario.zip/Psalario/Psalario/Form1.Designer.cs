﻿namespace Psalario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNomeFunc = new System.Windows.Forms.Label();
            this.lblSalbruto = new System.Windows.Forms.Label();
            this.NudFilhos = new System.Windows.Forms.Label();
            this.lblIliquotaInss = new System.Windows.Forms.Label();
            this.lblAliquotaIRPF = new System.Windows.Forms.Label();
            this.lblSalFam = new System.Windows.Forms.Label();
            this.lblSalLiqui = new System.Windows.Forms.Label();
            this.lblDescInss = new System.Windows.Forms.Label();
            this.lblDescIrpf = new System.Windows.Forms.Label();
            this.txtNomeFuncionario = new System.Windows.Forms.TextBox();
            this.txtAliIRPF = new System.Windows.Forms.TextBox();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.txtSalLiquido = new System.Windows.Forms.TextBox();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            this.txtAliINSS = new System.Windows.Forms.TextBox();
            this.numdFilhos = new System.Windows.Forms.NumericUpDown();
            this.mskbxAliINSS = new System.Windows.Forms.MaskedTextBox();
            this.btnVerDesc = new System.Windows.Forms.Button();
            this.btnLimparDados = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numdFilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNomeFunc
            // 
            this.lblNomeFunc.AutoSize = true;
            this.lblNomeFunc.Location = new System.Drawing.Point(16, 20);
            this.lblNomeFunc.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNomeFunc.Name = "lblNomeFunc";
            this.lblNomeFunc.Size = new System.Drawing.Size(93, 13);
            this.lblNomeFunc.TabIndex = 0;
            this.lblNomeFunc.Text = "Nome Funcionário";
            // 
            // lblSalbruto
            // 
            this.lblSalbruto.AutoSize = true;
            this.lblSalbruto.Location = new System.Drawing.Point(16, 55);
            this.lblSalbruto.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSalbruto.Name = "lblSalbruto";
            this.lblSalbruto.Size = new System.Drawing.Size(67, 13);
            this.lblSalbruto.TabIndex = 1;
            this.lblSalbruto.Text = "Salário Bruto";
            // 
            // NudFilhos
            // 
            this.NudFilhos.AutoSize = true;
            this.NudFilhos.Location = new System.Drawing.Point(16, 86);
            this.NudFilhos.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.NudFilhos.Name = "NudFilhos";
            this.NudFilhos.Size = new System.Drawing.Size(86, 13);
            this.NudFilhos.TabIndex = 2;
            this.NudFilhos.Text = "Número de filhos";
            // 
            // lblIliquotaInss
            // 
            this.lblIliquotaInss.AutoSize = true;
            this.lblIliquotaInss.Location = new System.Drawing.Point(16, 148);
            this.lblIliquotaInss.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblIliquotaInss.Name = "lblIliquotaInss";
            this.lblIliquotaInss.Size = new System.Drawing.Size(75, 13);
            this.lblIliquotaInss.TabIndex = 3;
            this.lblIliquotaInss.Text = "Alíquota INSS";
            // 
            // lblAliquotaIRPF
            // 
            this.lblAliquotaIRPF.AutoSize = true;
            this.lblAliquotaIRPF.Location = new System.Drawing.Point(16, 178);
            this.lblAliquotaIRPF.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAliquotaIRPF.Name = "lblAliquotaIRPF";
            this.lblAliquotaIRPF.Size = new System.Drawing.Size(74, 13);
            this.lblAliquotaIRPF.TabIndex = 4;
            this.lblAliquotaIRPF.Text = "Alíquota IRPF";
            // 
            // lblSalFam
            // 
            this.lblSalFam.AutoSize = true;
            this.lblSalFam.Location = new System.Drawing.Point(16, 212);
            this.lblSalFam.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSalFam.Name = "lblSalFam";
            this.lblSalFam.Size = new System.Drawing.Size(76, 13);
            this.lblSalFam.TabIndex = 5;
            this.lblSalFam.Text = "Salário Família";
            // 
            // lblSalLiqui
            // 
            this.lblSalLiqui.AutoSize = true;
            this.lblSalLiqui.Location = new System.Drawing.Point(16, 244);
            this.lblSalLiqui.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSalLiqui.Name = "lblSalLiqui";
            this.lblSalLiqui.Size = new System.Drawing.Size(78, 13);
            this.lblSalLiqui.TabIndex = 6;
            this.lblSalLiqui.Text = "Salário Líquido";
            this.lblSalLiqui.Click += new System.EventHandler(this.label7_Click);
            // 
            // lblDescInss
            // 
            this.lblDescInss.AutoSize = true;
            this.lblDescInss.Location = new System.Drawing.Point(287, 147);
            this.lblDescInss.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDescInss.Name = "lblDescInss";
            this.lblDescInss.Size = new System.Drawing.Size(81, 13);
            this.lblDescInss.TabIndex = 7;
            this.lblDescInss.Text = "Desconto INSS";
            // 
            // lblDescIrpf
            // 
            this.lblDescIrpf.AutoSize = true;
            this.lblDescIrpf.Location = new System.Drawing.Point(287, 180);
            this.lblDescIrpf.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDescIrpf.Name = "lblDescIrpf";
            this.lblDescIrpf.Size = new System.Drawing.Size(80, 13);
            this.lblDescIrpf.TabIndex = 8;
            this.lblDescIrpf.Text = "Desconto IRPF";
            // 
            // txtNomeFuncionario
            // 
            this.txtNomeFuncionario.Location = new System.Drawing.Point(119, 20);
            this.txtNomeFuncionario.Margin = new System.Windows.Forms.Padding(2);
            this.txtNomeFuncionario.Name = "txtNomeFuncionario";
            this.txtNomeFuncionario.Size = new System.Drawing.Size(451, 20);
            this.txtNomeFuncionario.TabIndex = 9;
            this.txtNomeFuncionario.TextChanged += new System.EventHandler(this.txtNomeFuncionario_TextChanged);
            this.txtNomeFuncionario.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNomeFuncionario_KeyPress);
            // 
            // txtAliIRPF
            // 
            this.txtAliIRPF.Enabled = false;
            this.txtAliIRPF.Location = new System.Drawing.Point(109, 177);
            this.txtAliIRPF.Margin = new System.Windows.Forms.Padding(2);
            this.txtAliIRPF.Name = "txtAliIRPF";
            this.txtAliIRPF.Size = new System.Drawing.Size(129, 20);
            this.txtAliIRPF.TabIndex = 12;
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Enabled = false;
            this.txtSalFamilia.Location = new System.Drawing.Point(109, 209);
            this.txtSalFamilia.Margin = new System.Windows.Forms.Padding(2);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.Size = new System.Drawing.Size(129, 20);
            this.txtSalFamilia.TabIndex = 13;
            // 
            // txtSalLiquido
            // 
            this.txtSalLiquido.Enabled = false;
            this.txtSalLiquido.Location = new System.Drawing.Point(109, 241);
            this.txtSalLiquido.Margin = new System.Windows.Forms.Padding(2);
            this.txtSalLiquido.Name = "txtSalLiquido";
            this.txtSalLiquido.Size = new System.Drawing.Size(129, 20);
            this.txtSalLiquido.TabIndex = 14;
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Enabled = false;
            this.txtDescINSS.Location = new System.Drawing.Point(387, 141);
            this.txtDescINSS.Margin = new System.Windows.Forms.Padding(2);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(129, 20);
            this.txtDescINSS.TabIndex = 15;
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Enabled = false;
            this.txtDescIRPF.Location = new System.Drawing.Point(387, 178);
            this.txtDescIRPF.Margin = new System.Windows.Forms.Padding(2);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(129, 20);
            this.txtDescIRPF.TabIndex = 16;
            // 
            // txtAliINSS
            // 
            this.txtAliINSS.Enabled = false;
            this.txtAliINSS.Location = new System.Drawing.Point(109, 145);
            this.txtAliINSS.Margin = new System.Windows.Forms.Padding(2);
            this.txtAliINSS.Name = "txtAliINSS";
            this.txtAliINSS.Size = new System.Drawing.Size(129, 20);
            this.txtAliINSS.TabIndex = 11;
            // 
            // numdFilhos
            // 
            this.numdFilhos.Location = new System.Drawing.Point(119, 86);
            this.numdFilhos.Margin = new System.Windows.Forms.Padding(2);
            this.numdFilhos.Name = "numdFilhos";
            this.numdFilhos.Size = new System.Drawing.Size(80, 20);
            this.numdFilhos.TabIndex = 17;
            // 
            // mskbxAliINSS
            // 
            this.mskbxAliINSS.Location = new System.Drawing.Point(119, 51);
            this.mskbxAliINSS.Margin = new System.Windows.Forms.Padding(2);
            this.mskbxAliINSS.Mask = "99000.00";
            this.mskbxAliINSS.Name = "mskbxAliINSS";
            this.mskbxAliINSS.Size = new System.Drawing.Size(175, 20);
            this.mskbxAliINSS.TabIndex = 18;
            // 
            // btnVerDesc
            // 
            this.btnVerDesc.Location = new System.Drawing.Point(387, 319);
            this.btnVerDesc.Margin = new System.Windows.Forms.Padding(2);
            this.btnVerDesc.Name = "btnVerDesc";
            this.btnVerDesc.Size = new System.Drawing.Size(174, 23);
            this.btnVerDesc.TabIndex = 19;
            this.btnVerDesc.Text = "Verifica Desconto";
            this.btnVerDesc.UseVisualStyleBackColor = true;
            this.btnVerDesc.Click += new System.EventHandler(this.btnVerDesc_Click);
            // 
            // btnLimparDados
            // 
            this.btnLimparDados.Location = new System.Drawing.Point(194, 319);
            this.btnLimparDados.Margin = new System.Windows.Forms.Padding(2);
            this.btnLimparDados.Name = "btnLimparDados";
            this.btnLimparDados.Size = new System.Drawing.Size(174, 23);
            this.btnLimparDados.TabIndex = 20;
            this.btnLimparDados.Text = "Limpar Dados";
            this.btnLimparDados.UseVisualStyleBackColor = true;
            this.btnLimparDados.Click += new System.EventHandler(this.btnLimparDados_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(608, 368);
            this.Controls.Add(this.btnLimparDados);
            this.Controls.Add(this.btnVerDesc);
            this.Controls.Add(this.mskbxAliINSS);
            this.Controls.Add(this.numdFilhos);
            this.Controls.Add(this.txtDescIRPF);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.txtSalLiquido);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.txtAliIRPF);
            this.Controls.Add(this.txtAliINSS);
            this.Controls.Add(this.txtNomeFuncionario);
            this.Controls.Add(this.lblDescIrpf);
            this.Controls.Add(this.lblDescInss);
            this.Controls.Add(this.lblSalLiqui);
            this.Controls.Add(this.lblSalFam);
            this.Controls.Add(this.lblAliquotaIRPF);
            this.Controls.Add(this.lblIliquotaInss);
            this.Controls.Add(this.NudFilhos);
            this.Controls.Add(this.lblSalbruto);
            this.Controls.Add(this.lblNomeFunc);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numdFilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNomeFunc;
        private System.Windows.Forms.Label lblSalbruto;
        private System.Windows.Forms.Label NudFilhos;
        private System.Windows.Forms.Label lblIliquotaInss;
        private System.Windows.Forms.Label lblAliquotaIRPF;
        private System.Windows.Forms.Label lblSalFam;
        private System.Windows.Forms.Label lblSalLiqui;
        private System.Windows.Forms.Label lblDescInss;
        private System.Windows.Forms.Label lblDescIrpf;
        private System.Windows.Forms.TextBox txtNomeFuncionario;
        private System.Windows.Forms.TextBox txtAliIRPF;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.TextBox txtSalLiquido;
        private System.Windows.Forms.TextBox txtDescINSS;
        private System.Windows.Forms.TextBox txtDescIRPF;
        private System.Windows.Forms.TextBox txtAliINSS;
        private System.Windows.Forms.NumericUpDown numdFilhos;
        private System.Windows.Forms.MaskedTextBox mskbxAliINSS;
        private System.Windows.Forms.Button btnVerDesc;
        private System.Windows.Forms.Button btnLimparDados;
    }
}

