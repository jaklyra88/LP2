﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

       

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnExecuta_Click(object sender, EventArgs e)
        {

            double ladoA, ladoB, ladoC;
            
            double.TryParse(txtValorA.Text, out ladoA);
            double.TryParse(txtValorB.Text, out ladoB);
            double.TryParse(txtValorC.Text, out ladoC);

            /* TESTE FORMAÇÃO DO TRIANGULO */


            if ( ladoA + ladoB > ladoC & ladoA + ladoC > ladoB
                && ladoB + ladoC > ladoA )
            {
                MessageBox.Show("É triângulo");

                if(ladoA == ladoB && ladoB == ladoC)
                {
                    MessageBox.Show("O triângulo é equilátero");
                }
                else if( ladoA != ladoB && ladoA != ladoC && ladoB != ladoC)
                {
                    MessageBox.Show("É um triângulo escaleno");
                }
                else
                {
                    MessageBox.Show("É um triângulo isósceles");
                }
    {

    }

            }
            else
            {
                MessageBox.Show("Não é triangulo");
            }

            txtValorA.Text = " ";
            txtValorB.Text = " ";
            txtValorC.Text = " ";

        }

      


        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }


        private void txtValorA_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Este campo só aceita números");
                txtValorA.Text = "";
            }

            

        }

      private void txtValorB_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Este campo só aceita números");
                txtValorB.Text = "";
            }

        }

      
        private void txtValorC_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Este campo só aceita números");
                txtValorC.Text = "";
            }

        }

        private void txtValorA_Validated(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(txtValorA.Text))
            {
                MessageBox.Show("Preenchimento Obrigatório!");
                txtValorA.Focus();
            }
        }

        private void txtValorB_Validated(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(txtValorB.Text))
            {
                MessageBox.Show("Preenchimento Obrigatório!");
                txtValorB.Focus();


            }

        }

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(txtValorC.Text))
            {
                MessageBox.Show("Preenchimento Obrigatório!");
                txtValorC.Focus();
            }
        }
    }
}
