﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses
{
    internal class Mensalista: Empregado
    {
        //Náo podemos validar - só podemos utilizar get e set
        public Double SalarioMensal { get; set; }

        //Sobrescrevendo o método

        public override double SalarioBruto()
        {
            return SalarioMensal;
        }

        public Mensalista() 
        {
            System.Windows.Forms.MessageBox.Show("Aqui é mensalista");
        }

        public Mensalista(int matx,string nomex, DataTime datax, double salx)
        {
            this.NomeEmpregado = nomex;
            this.Matricula = matx;
            this.DataEntradaEmpresa = datax;
            this.SalarioMensal = salx;
        }

        public static String Empresa = "Toyota";
        public const String Filial = "Filial Sorocaba";


    }
}
