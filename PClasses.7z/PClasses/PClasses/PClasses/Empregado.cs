﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses
{
    abstract internal class Empregado
    {

        //Atributos
        private int matricula; 
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;

        //Metodos - propriedade
        public int Matricula // propriedade
        {
            get { return matricula; }
            set { matricula = value; }
        }

        public string NomeEmpregado
        { 
            get { return nomeEmpregado; } 
            set {  nomeEmpregado = value; } 
        }
        public DateTime DataEntradaEmpresa
        {
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }
                
        }

        //virtual - permissão para reescrever o método que será utilizado
        public virtual int TempoTrabalho()
        {
            //Representa um intervalo de tempo
            TimeSpan span =
                DateTime.Today.Subtract(DataEntradaEmpresa);
            return (span.Days);
        }

        //dever ser implementado
        //Derived classes must implements this
        public abstract double SalarioBruto();
        //Classe Abstract - Não pode criar objetos a partir dela


        public Empregado()
        {

            System.Windows.Forms.MessageBox.Show("Aqui é empregado");

        }

        public Empregado(int mat, string nome, DateTime datax)
        {

            matricula = mat;    
            nomeEmpregado = nome;
            dataEntradaEmpresa = datax;

        }

    }
}
